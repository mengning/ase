This is a menu program!

Build Procedure
    $ make clean
    $ make
    $ ./menu # you can input help/version/quit cmd.
